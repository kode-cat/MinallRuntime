// Simple while loop test
print("Testing while loop...");

var i = 0;
var sum = 0;

while (i < 5) {
    sum = sum + i;
    i = i + 1;
}

print("Sum from 0 to 4:", sum);
print("Final i:", i);

print("While loop test completed successfully!");